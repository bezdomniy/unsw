void distributeTuples(Reln r) {
	PageID curPageID = r->sp;
	PageID replacementCurPageID = r->sp;
	PageID buddyPageID = r->sp + pow(2, r->depth);

	FILE* curFile = r->data;
	FILE* replacementCurFile = r->data;
	FILE* buddyFile = r->data;


	Page curPage;
	Page replacementCurPage = newPage();
	pageSetOvflow(replacementCurPage, pageOvflow(curPage));

	Page buddyPage = getPage(buddyFile, buddyPageID);

	int i;
	Bits p;
	char* data;

	PageID nextPageID;

	while (curPageID != NO_PAGE) {
		curPage = getPage(curFile, curPageID);
		
		i = 0;

		data = pageData(curPage);

		for (i = 0; i < pageNTuples(curPage); i++) {
			p = getLower(tupleHash(r, data[i]) , r->depth + 1);

			if (p == buddyPageID) {
				while (addToPage(buddyPage, data[i])) {
					nextPageID = addPage(r->ovflow);
					pageSetOvflow(buddyPage, nextPageID);

					putPage(buddyFile, buddyPageID, buddyPage);
					buddyFile = r->ovflow;
					
					buddyPage = getPage(buddyFile, nextPageID);
				}
			}
			else {
				while (addToPage(replacementCurPage, data[i])) {
					putPage(replacementCurFile, replacementCurPageID, replacementCurPage);
					replacementCurPageID = pageOvflow(replacementCurPage);
					replacementCurFile = r->ovflow;
					replacementCurPage = newPage();
				}
			}
		}


		curPageID = pageOvflow(curPage);
		curFile = r->ovflow;
		free(curPage);
	}
}